function validateAndGetFormData() {
    var stuIdVar = $("#stuId").val();
    if (stuIdVar === "") {
        alert("Student Roll-No Required Value");
        $("#stuId").focus();
        return "";
    }
    var stuNameVar = $("#stuName").val();
    if (stuNameVar === "") {
        alert("Student Name is Required Value");
        $("#stuName").focus();
        return "";
    }
    var stuClassVar = $("#stuClass").val();
    if (stuClassVar === "") {
        alert("Student Class is Required Value");
        $("#stuClass").focus();
        return "";
    }

    var stuDOBVar = $("#stuDOB").val();
    if (stuDOBVar === "") {
        alert("Student Birth-Date is Required Value");
        $("stuDOB").focus();
        return "";
    }

    var stuAddressVar = $("#stuAddress").val();
    if (stuAddressVar === "") {
        alert("Student Address is Required Value");
        $("#stuAddress").focus();
        return "";
    }

    var stuEnrollDateVar = $("stuEnrollDate").val();
    if (stuEnrollDateVar === "") {
        alert("Student Enrollment-Date is Required Value");
        $("stuEnrollDate").focus();
        return "";
    }

    var jsonStrObj = {
        stuId: stuIdVar,
        stuName: stuNameVar,
        stuClass: stuClassVar,
        stuDOB: stuDOBVar,
        stuAddress: stuAddressVar,
        stuEnrollDate: stuEnrollDateVar
    };
    return JSON.stringify(jsonStrObj);
}

function getstuIdASJsonObj() {
    var stuid = $("#stuId").val();
    var jsonStr = {
        id: stuid
    };
    return JSON.stringify(jsonStr);
}

function getStu() {
    var stuIdJsonObj = getstuIdASJsonObj();
    var getRequest = createGET_BY_KEYRequest(connToken,stuDBName, stuRelationName,stuIdJsonObj);
    jQuery.ajaxSetup({async: false});
    var resJsonObj = executeCommandAtGivenBaseUrl(getRequest,jpdbBaseURL,jpdbURL);
    jQuery.ajaxSetup({async: true});
    if (resJsonObj.status === 400) {
        $('#save').prop("disabled", false);
        $("#reset").prop("disabled", false);
        $("#stuName").focus();
    } else if (resJsonObj.status === 200) {
        $("#stuId").prop("disabled", true);
        fillData(resJsonObj);
        $("#change").prop("disabled", false);
        $("#reset").prop("disabled", false);
        $("#stuName").focus();
    }
}

function resetForm() {
    $("#stuId").val("");
    $("#stuName").val("");
    $("#stuClass").val("");
    $("#stuDOB").val("");
    $("#stuAddress").val("");
    $("#stuEnrollDate").val("");
    $('#stuId').focus();
}

function changeData() {
    $('#change').prop("disabled", true);
    jsonChg = validateData();
    var updateRequest = createUPDATERecordRequest(
            connToken,
            jsonChg,
            stuDBName,
            stuRelationName,
            localStorage.getItem("recno")
            );
    jQuery.ajaxSetup({async: false});
    var resJsonObj = executeCommandAtGivenBaseUrl(
            updateRequest.jpdBaseURL,
            jpdbIML
            );
    jQuery.ajaxSetup({async: true});
    console.log(resJsonObj);
    resetForm();
    $('#stuID').focus();
}

function saveData() {
    var jsonStr = validateAndGetFormData();
    if (jsonStr === "") {
        return;
    }
    var putReqStr = createPUTRequest(
            "90933177|-31949319635119543|90951071",
            jsonStr,
            "SCHOOL-DB",
            "STUDENT-TABLE"
            );

    alert(putReqStr);

    jQuery.ajaxSetup({async: false});
    var resultObj = executeCommandAtGivenBaseUrl(
            putReqStr,
            "http://api.login2explore.com:5577",
            "/api/iml"
            );
    jQuery.ajaxSetup({async: true});
    alert(JSON.stringify(resultObj));
    resetForm();
}

